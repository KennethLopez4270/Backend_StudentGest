package com.studengest.encuesta_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EncuestaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EncuestaServiceApplication.class, args);
	}

}
