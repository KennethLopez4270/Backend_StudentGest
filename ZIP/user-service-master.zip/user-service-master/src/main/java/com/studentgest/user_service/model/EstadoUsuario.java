package com.studentgest.user_service.model;

public enum EstadoUsuario {
    PENDIENTE,
    APROBADO,
    RECHAZADO
}

