package com.estudentgest.student_service.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MateriaDTO {
    private Long id_materia;
    private String nombre;
}
