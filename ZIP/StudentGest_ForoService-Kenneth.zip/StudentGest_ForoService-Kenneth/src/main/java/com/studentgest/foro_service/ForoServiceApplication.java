package com.studentgest.foro_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForoServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(ForoServiceApplication.class, args);
	}
}