package com.homework.homework_service.dto;

import lombok.Data;

@Data
public class CursoMateriaProfesorDTO {
    private Long idCmp;
    private Long idCurso;
    private Long idMateria;
    private Long idProfesor;
}
